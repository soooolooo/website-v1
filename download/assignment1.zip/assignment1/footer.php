<footer>
<?php
$format="%T %D";
$strf=strftime($format);
echo("Time now: $strf");
?>    
<p>All copyrights reserved to Osama Albeeshi</p>
</footer>
</html>
