<?php
    session_start();
?>

<header>
    <div class="dealer-logo">
        <a href="index.php">
            <img src="gfx/ccis.png">
        </a>
    </div>
    <div class="nav-bar">
        
        <a href="index.php">
            <div class="nav">
                <p>Home</p>
            </div>
        </a>
        <a href="courses.php">
            <div class="nav">
                <p>Courses</p>
            </div>
        </a>
        <a href="aboutus.php">
            <div class="nav">
                <p>About us</p>
            </div>
        </a>
        <a href="contactus.php">
            <div class="nav">
                <p>Contact us</p>
            </div>
        </a>
            
            <!-- <div class="nav">
                <?php
                
                ?>
            </div> -->
    </div>
</header>