<?php
    include 'head.php';
    include 'header.php';
?>

<main>
    <h1>Sorry, This page is not available.</h1>
    <h2>Please check it out later, Thank you.</h2>
</main>

<?php
    include 'footer.php';
?>