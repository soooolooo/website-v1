<?php
    include 'head.php';
    include 'header.php';
?>

<div class="title">
        <?php
            $strf=strftime("%H");
            if ($strf < 12){
                echo '<h1>Good morning!</h1>';
            }
            else if ($strf >= 18){
                echo '<h1>Good Evening!</h1>';
            }
            else if ($strf >= 12){
                echo '<h1>Good Afternoon!</h1>';
            }
        ?>
    </div>

<main>
    

    <div class="index">
        <h1>Overview</h1>
        <p style="text-align: left;">I would like to welcome you to the course website of the Information Technology Department at the Imam Mohammed bin Saud Islamic University. Ithe website aims to add courses to Information Technology Department.<br><br>
        
    IT department undertook new tasks that ensure that the computing infrastructure is suitable for any organization to operate efficiently and reliability, and meet the computer-related needs of individuals, and developing appropriate solutions for problems.<br><br>
    
    Today, All kinds of organizations dramatically rely on IT departments. They need to have appropriate regulations, and it is working properly, and to be locked dand are constantly updated and maintaned in a timely manner.</p>
    </div>
</main>

<?php
    include 'footer.php';
?>